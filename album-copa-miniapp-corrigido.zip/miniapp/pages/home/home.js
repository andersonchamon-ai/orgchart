// Home Page — Album da Copa 2026
const app = getApp()

Page({
  data: {
    packs: [
      { opened: false },
      { opened: false },
      { opened: false }
    ],
    packsExpireIn: '',
    completedTeams: [],
    almostTeams: [],
    duplicateCount: 0,
    sentCount: 0
  },

  onLoad() {
    this.fetchHomeData()
  },

  onShow() {
    this.fetchHomeData()
    this.startExpiryTimer()
  },

  onHide() {
    this.stopExpiryTimer()
  },

  async fetchHomeData() {
    try {
      const data = await app.request('/api/home')
      this.setData({
        packs: data.packs || this.data.packs,
        completedTeams: data.completedTeams || [],
        almostTeams: (data.almostTeams || []).map(t => ({
          ...t,
          percent: Math.round((t.collected / t.total) * 100),
          missing: t.total - t.collected
        })),
        duplicateCount: data.duplicateCount || 0,
        sentCount: data.sentCount || 0
      })
      
      if (data.packsExpireAt) {
        this._expiryTime = new Date(data.packsExpireAt).getTime()
      }
    } catch (err) {
      console.error('Failed to fetch home data:', err)
    }
  },

  startExpiryTimer() {
    this._timer = setInterval(() => {
      if (!this._expiryTime) return
      const now = Date.now()
      const diff = this._expiryTime - now
      if (diff <= 0) {
        this.setData({ packsExpireIn: 'Expirado!' })
        this.stopExpiryTimer()
        return
      }
      const hours = Math.floor(diff / 3600000)
      const mins = Math.floor((diff % 3600000) / 60000)
      this.setData({ packsExpireIn: `${hours}h ${mins}min` })
    }, 60000) // update every minute
  },

  stopExpiryTimer() {
    if (this._timer) {
      clearInterval(this._timer)
      this._timer = null
    }
  },

  onPackTap(e) {
    const index = e.currentTarget.dataset.index
    const pack = this.data.packs[index]
    if (pack.opened) return

    pz.navigateTo({
      url: `/pages/pack/pack?index=${index}`
    })
  },

  onTeamTap(e) {
    const teamId = e.currentTarget.dataset.id
    pz.switchTab({
      url: '/pages/album/album'
    })
  },

  onPrizeTap() {
    pz.showModal({
      title: '🏆 iPhone 17',
      content: 'Complete todas as figurinhas do álbum e ganhe um iPhone 17! Colete pacotes todos os dias e troque figurinhas com seus amigos pelo Phiz.',
      showCancel: false,
      confirmText: 'Entendi!'
    })
  },

  onShareAppMessage() {
    return {
      title: '⚽ Album da Copa 2026 — Ganhe um iPhone 17!',
      path: '/pages/home/home'
    }
  }
})
