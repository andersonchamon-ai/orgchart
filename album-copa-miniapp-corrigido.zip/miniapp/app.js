// Album da Copa 2026 — PhizChat Mini-App
App({
  globalData: {
    userInfo: null,
    baseUrl: 'https://api.albumdacopa.com', // TODO: set real backend URL
    token: null
  },

  onLaunch() {
    console.log('🏆 Album da Copa 2026 initialized')
    // Check login status
    this.checkLogin()
  },

  checkLogin() {
    const token = pz.getStorageSync('token')
    if (token) {
      this.globalData.token = token
      this.fetchUserInfo()
    }
  },

  login() {
    return new Promise((resolve, reject) => {
      pz.login({
        success: (res) => {
          if (res.code) {
            // Send code to backend to get session token
            pz.request({
              url: `${this.globalData.baseUrl}/api/auth/login`,
              method: 'POST',
              data: { code: res.code },
              success: (resp) => {
                if (resp.data && resp.data.token) {
                  this.globalData.token = resp.data.token
                  pz.setStorageSync('token', resp.data.token)
                  resolve(resp.data)
                } else {
                  reject(new Error('Login failed'))
                }
              },
              fail: reject
            })
          } else {
            reject(new Error('No login code'))
          }
        },
        fail: reject
      })
    })
  },

  fetchUserInfo() {
    this.request('/api/user/me').then(data => {
      this.globalData.userInfo = data
    }).catch(err => {
      console.error('Failed to fetch user info:', err)
    })
  },

  // Helper: authenticated API request
  request(path, options = {}) {
    return new Promise((resolve, reject) => {
      pz.request({
        url: `${this.globalData.baseUrl}${path}`,
        method: options.method || 'GET',
        data: options.data || {},
        header: {
          'content-type': 'application/json',
          'Authorization': `Bearer ${this.globalData.token || ''}`
        },
        success: (res) => {
          if (res.statusCode === 401) {
            // Token expired, re-login
            this.login().then(() => {
              this.request(path, options).then(resolve).catch(reject)
            }).catch(reject)
            return
          }
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(res.data)
          } else {
            reject(new Error(`API error: ${res.statusCode}`))
          }
        },
        fail: reject
      })
    })
  }
})
